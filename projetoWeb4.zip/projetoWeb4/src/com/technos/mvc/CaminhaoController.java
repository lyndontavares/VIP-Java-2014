package com.technos.mvc;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class CaminhaoController {
    @Autowired
    private CaminhaoRepository caminhaoRepository;

    @RequestMapping(value = "/caminhao", method = RequestMethod.GET)
    public String listCaminhoes(ModelMap model) {
        model.addAttribute("caminhao", new Caminhao());
        model.addAttribute("caminhoes", caminhaoRepository.findAll());
        return "caminhao";
    }

    @RequestMapping(value = "/api/caminhao", method = RequestMethod.GET)
    public
    @ResponseBody
    String listCaminhoesJson(ModelMap model) throws JSONException {
        JSONArray caminhaoArray = new JSONArray();
        for (Caminhao caminhao : caminhaoRepository.findAll()) {
            JSONObject caminhaoJSON = new JSONObject();
            caminhaoJSON.put("id", caminhao.getId());
            caminhaoJSON.put("placa", caminhao.getPlaca());
            caminhaoJSON.put("potencia", caminhao.getPotencia());
            caminhaoJSON.put("combustivel", caminhao.getCombustivel());
            caminhaoJSON.put("velocidade", caminhao.getVelocidade());
            caminhaoArray.put(caminhaoJSON);
        }
        return caminhaoArray.toString();
    }

    @RequestMapping(value = "/caminhao/add", method = RequestMethod.POST)
    public String addUser(@ModelAttribute("caminhao") Caminhao caminhao, BindingResult result) {
    	    caminhaoRepository.save(caminhao);
        return "redirect:/caminhao";
    }

    @RequestMapping("/caminhao/delete/{caminhaoId}")
    public String deleteUser(@PathVariable("caminhaoId") Long caminhaoId) {
    	    caminhaoRepository.delete(caminhaoRepository.findOne(caminhaoId));
        return "redirect:/caminhao";
    }
}