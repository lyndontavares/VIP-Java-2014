package br.com.technos.modelo;

public interface CheckInCheckOut {

	abstract void checkIn();
	
	abstract void checkOut();
	
	
	
}
