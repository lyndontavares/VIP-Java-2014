package br.com.technos.modelo;


public class Entrega {

	private Veiculo veiculo = new Veiculo();

	private Motorista motorista;
	
	private Mercadoria mercadoria;
	
	private Cliente cliente;
	
	private Trajeto trajeto;
	
	
	

	public Veiculo getVeiculo() {
		return veiculo;
	}

	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}

	public Motorista getMotorista() {
		return motorista;
	}

	public void setMotorista(Motorista motorista) {
		this.motorista = motorista;
	}

	public Mercadoria getMercadoria() {
		return mercadoria;
	}

	public void setMercadoria(Mercadoria mercadoria) {
		this.mercadoria = mercadoria;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Trajeto getTrajeto() {
		return trajeto;
	}

	public void setTrajeto(Trajeto trajeto) {
		this.trajeto = trajeto;
	}
	
	
	public void entregarMercadoria( Veiculo veiculo, Motorista motorista, 
			Mercadoria mercadoria, Cliente cliente, Trajeto trajeto ){
		System.out.println( this.toString() );
	}


	@Override
	public String toString() {
		return "Entrega [veiculo=" + veiculo + ", motorista=" + motorista
				+ ", mercadoria=" + mercadoria + ", cliente=" + cliente
				+ ", trajeto=" + trajeto + "]";
	}

	public Entrega(Veiculo veiculo, Motorista motorista, Mercadoria mercadoria,
			Cliente cliente, Trajeto trajeto) {
		super();
		this.veiculo = veiculo;
		this.motorista = motorista;
		this.mercadoria = mercadoria;
		this.cliente = cliente;
		this.trajeto = trajeto;
	}

	
	
	
}
