package br.com.technos.model;

import java.io.Serializable;
 


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
 
import javax.persistence.Table;
 
@Entity
@Table(name="caminhao")
public class Caminhao implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name="placa")
	private String placa;

	@Column(name="potencia")
	private int potenciaMotor;
	
	@Column(name="combustivel")
	private double combustivel;

	@Column(name="velocidade")
	private int velocidadeMedia;
	
	public Caminhao() {
	}

 

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getPlaca() {
		return placa;
	}



	public void setPlaca(String placa) {
		this.placa = placa;
	}



	public int getPotenciaMotor() {
		return potenciaMotor;
	}



	public void setPotenciaMotor(int potenciaMotor) {
		this.potenciaMotor = potenciaMotor;
	}



	public double getCombustivel() {
		return combustivel;
	}



	public void setCombustivel(double combustivel) {
		this.combustivel = combustivel;
	}



	public int getVelocidadeMedia() {
		return velocidadeMedia;
	}



	public void setVelocidadeMedia(int velocidadeMedia) {
		this.velocidadeMedia = velocidadeMedia;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Caminhao other = (Caminhao) obj;
		if (id != other.id)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Caminhao [id=" + id + ", placa=" + placa + ", potenciMotor="
				+ potenciaMotor + ", combustivel=" + combustivel
				+ ", velocidadeMedia=" + velocidadeMedia + "]";
	}



}