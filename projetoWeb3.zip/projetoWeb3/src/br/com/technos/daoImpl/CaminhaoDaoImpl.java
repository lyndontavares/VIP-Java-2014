package br.com.technos.daoImpl;

import br.com.technos.dao.GenericDao;
import br.com.technos.dao.GenericDaoImpl;
import br.com.technos.model.Caminhao;

public class CaminhaoDaoImpl extends GenericDaoImpl<Caminhao, Integer> implements GenericDao<Caminhao, Integer> {

}
