package br.com.technos.teste;

import java.util.Date;

import br.com.technos.modelo.Caminhao;
import br.com.technos.modelo.Cliente;
import br.com.technos.modelo.Entrega;
import br.com.technos.modelo.Mercadoria;
import br.com.technos.modelo.Motorista;
import br.com.technos.modelo.Trajeto;
import br.com.technos.modelo.Veiculo;

public class Teste {

	public static void main(String[] args ) {
		 
		
		Caminhao caminhao = new Caminhao();
		
		caminhao.checkIn();
		
		caminhao.checkOut();
		
		
		Date date = new Date();
		
		Veiculo veiculo= new Veiculo(100,100,100);
		Motorista motorista= new Motorista("Lyndon");
		Mercadoria mercadoria= new Mercadoria(100,"Computador");
		Cliente cliente = new Cliente(99,"Nome do Cliente");
		Trajeto trajeto= new Trajeto("Foz","Cascavel",date,300);
		
		Entrega entrega = new Entrega(veiculo, motorista, mercadoria, cliente, trajeto);
		
		System.out.println(entrega);
		

	}

}
