package br.com.technos.teste;



public class TesteCaminhaoDao {


	}

