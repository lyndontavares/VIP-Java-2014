package br.com.technos.teste;

import java.util.List;

import br.com.technos.daoImpl.CaminhaoDaoImpl;
import br.com.technos.model.Caminhao;

public class TesteCaminhaoGenericDao {

	public static void main(String... args) {

		
		//objeto caminhao de model
		Caminhao caminhao = new Caminhao();
		caminhao.setPlaca("XDX-0101");

		//pesistencia usando classe generica
		CaminhaoDaoImpl caminhaoDao = new CaminhaoDaoImpl();
		caminhaoDao.save(caminhao);

		//impressao usando dao generico
		List<Caminhao> listaCaminhoes = caminhaoDao.getAll(Caminhao.class);

		for (Caminhao c : listaCaminhoes) {
			System.out.println(c);
		}

	}
}