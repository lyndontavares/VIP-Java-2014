package br.com.technos.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.technos.model.Caminhao;

public class TesteCaminhaoJPA {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa");

		EntityManager em = factory.createEntityManager();

		em.getTransaction().begin();
		Caminhao c = new Caminhao();
		c.setPlaca("ZZZ-0101");
		em.persist(c);
		em.getTransaction().commit();

	}

}
