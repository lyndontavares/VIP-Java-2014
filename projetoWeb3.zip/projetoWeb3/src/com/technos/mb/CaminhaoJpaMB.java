package com.technos.mb;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.technos.daoImpl.CaminhaoDaoImpl;
import br.com.technos.model.Caminhao;

@ManagedBean(name="caminhaoMB")
@ViewScoped
public class CaminhaoJpaMB  implements Serializable{

	private static final long serialVersionUID = 1L;

	private Caminhao caminhao;
	
	private List<Caminhao> listaCaminhao;
	
	
	@PostConstruct
	public void init(){
		setCaminhao(new Caminhao());
	}

	public void cadastrar() {
		CaminhaoDaoImpl dao = new CaminhaoDaoImpl();
		dao.save(caminhao);
		caminhao = new Caminhao();
		listaCaminhao = dao.getAll(Caminhao.class);		
	}

	public void excluir() {
		CaminhaoDaoImpl dao = new CaminhaoDaoImpl();
		dao.remove(caminhao);
		listaCaminhao = dao.getAll(Caminhao.class);
	}

	
	public Caminhao getCaminhao() {
		return caminhao;
	}

	public void setCaminhao(Caminhao caminhao) {
		this.caminhao = caminhao;
	}

	public List<Caminhao> getListaCaminhao() {
		return listaCaminhao;
	}

	public void setListaCaminhao(List<Caminhao> listaCaminhao) {
		this.listaCaminhao = listaCaminhao;
	}
	
	
}
