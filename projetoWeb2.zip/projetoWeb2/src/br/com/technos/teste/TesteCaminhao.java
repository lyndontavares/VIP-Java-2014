package br.com.technos.teste;

import com.technos.mb.CaminhaoMB;

public class TesteCaminhao {

	public static void main(String[] args) {
		 
		
		CaminhaoMB mb = new CaminhaoMB();
		
		mb.init();
		
		
		

	}

}
