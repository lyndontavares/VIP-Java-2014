package br.com.technos.modelo;

import java.util.Date;


public class Trajeto {

	private String localOrigem;
	private String localDestino;
	private Date tempoEstimado;
	private double distacia;
	public String getLocalOrigem() {
		return localOrigem;
	}
	public void setLocalOrigem(String localOrigem) {
		this.localOrigem = localOrigem;
	}
	public String getLocalDestino() {
		return localDestino;
	}
	public void setLocalDestino(String localDestino) {
		this.localDestino = localDestino;
	}
	public Date getTempoEstimado() {
		return tempoEstimado;
	}
	public void setTempoEstimado(Date tempoEstimado) {
		this.tempoEstimado = tempoEstimado;
	}
	public double getDistacia() {
		return distacia;
	}
	public void setDistacia(double distacia) {
		this.distacia = distacia;
	}
	@Override
	public String toString() {
		return "Trajeto [localOrigem=" + localOrigem + ", localDestino="
				+ localDestino + ", tempoEstimado=" + tempoEstimado
				+ ", distacia=" + distacia + "]";
	}
	public Trajeto(String localOrigem, String localDestino, Date tempoEstimado,
			double distacia) {
		super();
		this.localOrigem = localOrigem;
		this.localDestino = localDestino;
		this.tempoEstimado = tempoEstimado;
		this.distacia = distacia;
	}
	
	
	
	
}
