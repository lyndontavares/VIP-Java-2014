package br.com.technos.modelo;


public class Veiculo implements CheckInCheckOut {

	private String placa;
	private int potenciaMotor;
	private double combustivel;
	private double velocidadeMedia;

	public Veiculo() {
	}

	public int getPotenciaMotor() {
		return potenciaMotor;
	}

	public void setPotenciaMotor(int potenciaMotor) {
		this.potenciaMotor = potenciaMotor;
	}

	public double getCombustivel() {
		return combustivel;
	}

	public void setCombustivel(double combustivel) {
		this.combustivel = combustivel;
	}

	public double getVelocidadeMedia() {
		return velocidadeMedia;
	}

	public void setVelocidadeMedia(double velocidadeMedia) {
		this.velocidadeMedia = velocidadeMedia;
	}

	@Override
	public void checkIn() {
		System.out.println("CheckIn realizado"); 
		
	}

	@Override
	public void checkOut() {
		 System.out.println("Checkout realizaqdo");
		
	}

	public Veiculo(int potenciaMotor, double combustivel, double velocidadeMedia) {
		super();
		this.potenciaMotor = potenciaMotor;
		this.combustivel = combustivel;
		this.velocidadeMedia = velocidadeMedia;
	}

	@Override
	public String toString() {
		return "Veiculo [potenciaMotor=" + potenciaMotor + ", combustivel="
				+ combustivel + ", velocidadeMedia=" + velocidadeMedia + "]";
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

}