package br.com.technos.modelo;


public class Motorista {

	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Motorista(String nome) {
		super();
		this.nome = nome;
	}

	@Override
	public String toString() {
		return "Motorista [nome=" + nome + "]";
	}
	
}
