package com.technos.mb;

import java.io.Serializable;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.technos.modelo.Caminhao;

@ManagedBean
@ViewScoped
public class CaminhaoMB implements Serializable {

	private static final long serialVersionUID = 1L;

	private Caminhao caminhao;

	private ArrayList<Caminhao> listaCaminhao;

	public Caminhao getCaminhao() {
		return caminhao;
	}

	public void setCaminhao(Caminhao caminhao) {
		this.caminhao = caminhao;
	}

	@PostConstruct
	public void init() {

		if (listaCaminhao == null) {
			listaCaminhao = new ArrayList<Caminhao>();
			for (int i = 1; i <= 22; i++) {
				caminhao = new Caminhao("JSF-000" + i, i, i*2, i*4);
				listaCaminhao.add(caminhao);
				System.out.println(caminhao);
			}
		}
		caminhao = new Caminhao();
	}

	public void cadastrar() {

		listaCaminhao.add(caminhao);
		caminhao = new Caminhao();

	}

	public void excluir() {

		listaCaminhao.remove(caminhao);
		caminhao = new Caminhao();

	}

	public ArrayList<Caminhao> getListaCaminhao() {
		return listaCaminhao;
	}

	public void setListaCaminhao(ArrayList<Caminhao> listaCaminhao) {
		this.listaCaminhao = listaCaminhao;
	}

}
