package projetoWeb1;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.*;

@ManagedBean
public class IndexMB  implements Serializable{

	private static final long serialVersionUID = 1L;
	private String nome;
	
	@PostConstruct
	public void init(){
		setNome("Ola mundo");
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	

	public String mensagem(){
		return "Olá mundo";
	}
	
}
