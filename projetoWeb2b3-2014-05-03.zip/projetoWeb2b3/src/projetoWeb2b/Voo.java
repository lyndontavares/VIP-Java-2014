package projetoWeb2b;

import java.util.Date;


public class Voo {

	private int numero;
	
	private Aviao aviao;
	
	private Trajeto trajeto;
	
	private Date horarioPartida;
	
	private Date horarioChegada;

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Aviao getAviao() {
		return aviao;
	}

	public void setAviao(Aviao aviao) {
		this.aviao = aviao;
	}

	public Trajeto getTrajeto() {
		return trajeto;
	}

	public void setTrajeto(Trajeto trajeto) {
		this.trajeto = trajeto;
	}

	public Date getHorarioPartida() {
		return horarioPartida;
	}

	public void setHorarioPartida(Date horarioPartida) {
		this.horarioPartida = horarioPartida;
	}

	public Date getHorarioChegada() {
		return horarioChegada;
	}

	public void setHorarioChegada(Date horarioChegada) {
		this.horarioChegada = horarioChegada;
	}

	@Override
	public String toString() {
		return "Voo [numero=" + numero + ", aviao=" + aviao + ", trajeto="
				+ trajeto + ", horarioPartida=" + horarioPartida
				+ ", horarioChegada=" + horarioChegada + "]";
	}

	public Voo(int numero, Aviao aviao, Trajeto trajeto, Date horarioPartida,
			Date horarioChegada) {
		super();
		this.numero = numero;
		this.aviao = aviao;
		this.trajeto = trajeto;
		this.horarioPartida = horarioPartida;
		this.horarioChegada = horarioChegada;
	}
	
	public void abastecerAviao(double quantidadeCombustivel) {
		getAviao().setQuantidadeCombustivel(quantidadeCombustivel);
		System.out.println( "Aviao "+getAviao().getPrefixo()+" abastecido com "+quantidadeCombustivel);
		
	}
	
	public void decolarAviao() {
		getAviao().setQuantidadeCombustivel( getAviao().getQuantidadeCombustivel() - 100 );
		System.out.println("Aviao "+getAviao().getPrefixo()+" decolou! consumo: "+getAviao().getQuantidadeCombustivel() );
	}

	public void voarAviao() {
		getAviao().setQuantidadeCombustivel( getAviao().getQuantidadeCombustivel() - 100 );
		System.out.println("Aviao "+getAviao().getPrefixo()+" voando! consumo: "+getAviao().getQuantidadeCombustivel() );
	}
	
	public void aterrisarAviao() {
		getAviao().setQuantidadeCombustivel( getAviao().getQuantidadeCombustivel() - 100 );
		System.out.println("Aviao "+getAviao().getPrefixo()+" aterrisando! consumo: "+getAviao().getQuantidadeCombustivel() );
	}
	
	public void relatorioDoVoo(){
		
		System.out.println("Relatorio do Voo");
		
		System.out.println("1 - Trajeto");
		
		System.out.println(getTrajeto());
		
		System.out.println("2 - Avi�o");
		
		System.out.println(getAviao());
		
		System.out.println("3 - Voo");
		
		System.out.println(this.toString());
		
	}
	
	

	
}
