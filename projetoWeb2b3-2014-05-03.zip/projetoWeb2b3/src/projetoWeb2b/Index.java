package projetoWeb2b;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;


@ManagedBean(name="indexMB")
public class Index {

	private String nome;
	
	private String autor;
	
	private Date data;
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@PostConstruct
	public void init(){
		nome="Lyndon";
		autor="Lyndon";
		data=new Date();
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}
	
	
}
