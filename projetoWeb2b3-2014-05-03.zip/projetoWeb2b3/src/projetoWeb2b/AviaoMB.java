package projetoWeb2b;

import java.io.Serializable;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;



@ManagedBean(name="aviaoMB")
public class AviaoMB implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Aviao aviao;
	
	private ArrayList<Aviao> listaAvioes;

	public Aviao getAviao() {
		return aviao;
	}

	public void setAviao(Aviao aviao) {
		this.aviao = aviao;
	}

	
	@PostConstruct
	public void init() {
		aviao = new Aviao();
		listaAvioes = new ArrayList<Aviao>();
		
		for(int i=1; i<=10; i++){
			
			listaAvioes.add( 
			new Aviao("ZZZ-000"+i, 100+i, 100+i, 100+i ) );
		}
		
	}

	public ArrayList<Aviao> getListaAvioes() {
		return listaAvioes;
	}

	public void setListaAvioes(ArrayList<Aviao> listaAvioes) {
		this.listaAvioes = listaAvioes;
	}
	
	public void cadastrar() {
		listaAvioes.add(aviao);
		aviao=new Aviao();
	}
	
	public void excluir(){
		listaAvioes.remove(aviao);
	}


}
