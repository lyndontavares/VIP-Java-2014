package projetoWeb2b;

public class Trajeto {

	private String nome;
	
	private String pontoPartida;
	
	private String pontoChegada;
	
	private double distancia;
	
	private double combustivel;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPontoPartida() {
		return pontoPartida;
	}

	public void setPontoPartida(String pontoPartida) {
		this.pontoPartida = pontoPartida;
	}

	public String getPontoChegada() {
		return pontoChegada;
	}

	public void setPontoChegada(String pontoChegada) {
		this.pontoChegada = pontoChegada;
	}

	public double getDistancia() {
		return distancia;
	}

	public void setDistancia(double distancia) {
		this.distancia = distancia;
	}

	public double getCombustivel() {
		return combustivel;
	}

	public void setCombustivel(double combustivel) {
		this.combustivel = combustivel;
	}

	@Override
	public String toString() {
		return "Trajeto [nome=" + nome + ", pontoPartida=" + pontoPartida
				+ ", pontoChegada=" + pontoChegada + ", distancia=" + distancia
				+ ", combustivel=" + combustivel + "]";
	}

	public Trajeto(String nome) {
		super();
		this.nome = nome;
	}


	
	
}
