package projetoWeb2b;

public class Aviao {

	private double quantidadeCombustivel;
	
	private double consumo;

	private double velocidade;
	
	private String prefixo;

	public double getConsumo() {
		return consumo;
	}

	public void setConsumo(double consumo) {
		this.consumo = consumo;
	}

	public double getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(double velocidade) {
		this.velocidade = velocidade;
	}

	public String getPrefixo() {
		return prefixo;
	}

	public void setPrefixo(String prefixo) {
		this.prefixo = prefixo;
	}
	
	
	public void prepararAviao(String prefixo, double consumo, double velocidade, double quantidadeCombustivel) {
		this.consumo = consumo;
		this.velocidade = velocidade;
		this.prefixo = prefixo;
		this.quantidadeCombustivel = quantidadeCombustivel;
	}

	@Override
	public String toString() {
		return "Aviao [consumo=" + consumo + ", velocidade=" + velocidade
				+ ", prefixo=" + prefixo + "]";
	}

	public Aviao(String prefixo, double consumo, double velocidade, double quantidadeCombustivel) {
		super();
		this.consumo = consumo;
		this.velocidade = velocidade;
		this.prefixo = prefixo;
		this.quantidadeCombustivel = quantidadeCombustivel;
	}
	

	public Aviao() {
		
	}

	public double getQuantidadeCombustivel() {
		return quantidadeCombustivel;
	}

	public void setQuantidadeCombustivel(double quantidadeCombustivel) {
		this.quantidadeCombustivel = quantidadeCombustivel;
	}
	
	
	
	
}


 